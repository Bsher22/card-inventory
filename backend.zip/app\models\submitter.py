"""
Submitter Model

Third-party grading/authentication submission services.
"""

from sqlalchemy import Column, String, Boolean, Text, DateTime, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
import uuid

from app.db.base_class import Base


class Submitter(Base):
    """Third-party submission service (PWCC, MySlabs, etc.)"""
    
    __tablename__ = "submitters"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), unique=True, nullable=False)
    short_name = Column(String(20), nullable=True)
    website = Column(String(255), nullable=True)
    contact_email = Column(String(255), nullable=True)
    contact_phone = Column(String(50), nullable=True)
    
    # Service capabilities
    offers_grading = Column(Boolean, nullable=False, default=True)
    offers_authentication = Column(Boolean, nullable=False, default=True)
    
    # Status
    is_active = Column(Boolean, nullable=False, default=True)
    is_default = Column(Boolean, nullable=False, default=False)
    
    # Notes
    notes = Column(Text, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # Relationships
    grading_submissions = relationship("CardGradingSubmission", back_populates="submitter")
    auth_submissions = relationship("AuthSubmission", back_populates="submitter")

    def __repr__(self):
        return f"<Submitter {self.name}>"