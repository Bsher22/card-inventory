/**
 * API client for consigner player pricing
 */

import { apiClient } from './client';
import type {
  ConsignerPlayerPrice,
  ConsignerPlayerPriceCreate,
  ConsignerPlayerPriceUpdate,
  PricingMatrixResponse,
  PricingMatrixParams,
  BulkPriceCreate,
  BulkPriceResult,
  PriceLookupResponse,
  ConsignerPriceSummary,
} from '../types/consignerPricing';

const BASE_URL = '/api/consigner-prices';

export const consignerPricingApi = {
  // ============================================
  // MATRIX
  // ============================================
  
  /**
   * Get the pricing matrix (players vs consigners)
   */
  async getMatrix(params: PricingMatrixParams = {}): Promise<PricingMatrixResponse> {
    const searchParams = new URLSearchParams();
    
    if (params.consigner_ids?.length) {
      searchParams.set('consigner_ids', params.consigner_ids.join(','));
    }
    if (params.player_search) {
      searchParams.set('player_search', params.player_search);
    }
    if (params.only_with_prices) {
      searchParams.set('only_with_prices', 'true');
    }
    if (params.limit) {
      searchParams.set('limit', params.limit.toString());
    }
    if (params.offset) {
      searchParams.set('offset', params.offset.toString());
    }
    
    const query = searchParams.toString();
    const url = `${BASE_URL}/matrix${query ? `?${query}` : ''}`;
    
    const response = await apiClient.get(url);
    return response.json();
  },

  // ============================================
  // CRUD
  // ============================================

  /**
   * Create a new price entry
   */
  async createPrice(data: ConsignerPlayerPriceCreate): Promise<ConsignerPlayerPrice> {
    const response = await apiClient.post(BASE_URL, data);
    return response.json();
  },

  /**
   * Get a single price by ID
   */
  async getPrice(priceId: string): Promise<ConsignerPlayerPrice> {
    const response = await apiClient.get(`${BASE_URL}/${priceId}`);
    return response.json();
  },

  /**
   * Update a price entry
   */
  async updatePrice(
    priceId: string,
    data: ConsignerPlayerPriceUpdate
  ): Promise<ConsignerPlayerPrice> {
    const response = await apiClient.patch(`${BASE_URL}/${priceId}`, data);
    return response.json();
  },

  /**
   * Delete (deactivate) a price entry
   */
  async deletePrice(priceId: string): Promise<void> {
    await apiClient.delete(`${BASE_URL}/${priceId}`);
  },

  // ============================================
  // BULK OPERATIONS
  // ============================================

  /**
   * Bulk create or update prices
   */
  async bulkUpsert(data: BulkPriceCreate): Promise<BulkPriceResult> {
    const response = await apiClient.post(`${BASE_URL}/bulk`, data);
    return response.json();
  },

  // ============================================
  // LOOKUPS
  // ============================================

  /**
   * Look up best price for a player
   */
  async lookupPlayerPrice(
    playerId: string,
    preferConsignerId?: string
  ): Promise<PriceLookupResponse> {
    const params = preferConsignerId
      ? `?prefer_consigner_id=${preferConsignerId}`
      : '';
    const response = await apiClient.get(
      `${BASE_URL}/lookup/player/${playerId}${params}`
    );
    return response.json();
  },

  /**
   * Get pricing summary for a consigner
   */
  async getConsignerSummary(consignerId: string): Promise<ConsignerPriceSummary> {
    const response = await apiClient.get(
      `${BASE_URL}/consigner/${consignerId}/summary`
    );
    return response.json();
  },

  /**
   * Get all prices for a consigner
   */
  async getConsignerPrices(consignerId: string): Promise<ConsignerPlayerPrice[]> {
    const response = await apiClient.get(
      `${BASE_URL}/consigner/${consignerId}/prices`
    );
    return response.json();
  },
};

export default consignerPricingApi;
