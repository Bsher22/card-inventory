-- Migration: Add consigner_player_prices table
-- Purpose: Track per-player pricing quotes from each consigner
-- Run this on Railway PostgreSQL

-- ============================================
-- CONSIGNER PLAYER PRICES TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS consigner_player_prices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    consigner_id UUID NOT NULL REFERENCES consigners(id) ON DELETE CASCADE,
    player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,
    
    -- Pricing
    price_per_card DECIMAL(10,2) NOT NULL,
    
    -- Metadata
    notes TEXT,                          -- e.g., "Spring training only", "Team items extra"
    effective_date DATE,                 -- When this price became effective
    is_active BOOLEAN DEFAULT TRUE,      -- Can deactivate old prices without deleting
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Ensure one active price per consigner/player combination
    CONSTRAINT uq_consigner_player_active UNIQUE (consigner_id, player_id) 
        WHERE (is_active = true)
);

-- Note: The partial unique constraint above may not work in all PostgreSQL versions
-- Alternative approach - drop the WHERE clause and handle in application logic:
-- CONSTRAINT uq_consigner_player UNIQUE (consigner_id, player_id)

-- If the partial unique constraint fails, use this instead:
-- ALTER TABLE consigner_player_prices 
--     DROP CONSTRAINT IF EXISTS uq_consigner_player_active;
-- CREATE UNIQUE INDEX uq_consigner_player_active 
--     ON consigner_player_prices(consigner_id, player_id) 
--     WHERE is_active = true;

-- Indexes for common queries
CREATE INDEX idx_cpp_consigner ON consigner_player_prices(consigner_id);
CREATE INDEX idx_cpp_player ON consigner_player_prices(player_id);
CREATE INDEX idx_cpp_active ON consigner_player_prices(is_active) WHERE is_active = true;
CREATE INDEX idx_cpp_price ON consigner_player_prices(price_per_card);

-- Comments
COMMENT ON TABLE consigner_player_prices IS 'Per-player pricing quotes from consigners';
COMMENT ON COLUMN consigner_player_prices.price_per_card IS 'What this consigner charges for this specific player';
COMMENT ON COLUMN consigner_player_prices.effective_date IS 'When this price quote was received/became effective';
COMMENT ON COLUMN consigner_player_prices.is_active IS 'FALSE to keep historical prices without using them';
