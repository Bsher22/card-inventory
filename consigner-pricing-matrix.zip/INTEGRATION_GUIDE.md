# Consigner Player Pricing Feature

## Overview

This feature adds a **Pricing Matrix** that tracks what each consigner charges for specific players. It helps you:

1. **Compare prices** across consigners for the same player
2. **Find the best deal** when sending cards out for signatures  
3. **Auto-suggest fees** when creating consignments
4. **Track historical pricing** for better negotiation

---

## Installation

### 1. Database Migration

Run this on Railway PostgreSQL:

```sql
-- Connect to your database and run:
\i migrations/add_consigner_player_prices.sql
```

Or paste the contents directly into psql.

### 2. Backend Files

Copy these files to your backend:

| Source | Destination |
|--------|-------------|
| `backend/models/consigner_player_price.py` | `backend/models/` |
| `backend/schemas/consigner_player_price.py` | `backend/schemas/` |
| `backend/services/consigner_player_price_service.py` | `backend/services/` |
| `backend/routes/consigner_player_price.py` | `backend/routes/` |

### 3. Update Barrel Exports

**models/__init__.py** - Add:
```python
from .consigner_player_price import ConsignerPlayerPrice
```

**schemas/__init__.py** - Add:
```python
from .consigner_player_price import (
    ConsignerPlayerPriceCreate,
    ConsignerPlayerPriceUpdate,
    ConsignerPlayerPriceResponse,
    PricingMatrixResponse,
    BulkPriceCreate,
    BulkPriceResult,
    PriceLookupResponse,
    ConsignerPriceSummary,
)
```

**routes/__init__.py** - Add:
```python
from .consigner_player_price import router as consigner_player_price_router
```

### 4. Register Routes in main.py

```python
from routes import consigner_player_price_router

app.include_router(consigner_player_price_router)
```

### 5. Update Model Relationships

**models/consigner.py** - Add relationship:
```python
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .consigner_player_price import ConsignerPlayerPrice

class Consigner(Base):
    # ... existing fields ...
    
    # Add this relationship
    player_prices: Mapped[list["ConsignerPlayerPrice"]] = relationship(
        back_populates="consigner", cascade="all, delete-orphan"
    )
```

**models/player.py** - Add relationship:
```python
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .consigner_player_price import ConsignerPlayerPrice

class Player(Base):
    # ... existing fields ...
    
    # Add this relationship
    consigner_prices: Mapped[list["ConsignerPlayerPrice"]] = relationship(
        back_populates="player", cascade="all, delete-orphan"
    )
```

### 6. Frontend Files

Copy these files to your frontend:

| Source | Destination |
|--------|-------------|
| `frontend/types/consignerPricing.ts` | `frontend/src/types/` |
| `frontend/api/consignerPricingApi.ts` | `frontend/src/api/` |
| `frontend/pages/PricingMatrix.tsx` | `frontend/src/pages/` |
| `frontend/components/PriceSuggestion.tsx` | `frontend/src/components/` |

### 7. Update Frontend Exports

**types/index.ts** - Add:
```typescript
export * from './consignerPricing';
```

**api/client.ts** - Add to exports:
```typescript
export { consignerPricingApi } from './consignerPricingApi';
```

### 8. Add Route

**App.tsx** - Add the route:
```tsx
import PricingMatrix from './pages/PricingMatrix';

// In your Routes:
<Route path="/pricing-matrix" element={<PricingMatrix />} />
```

### 9. Add Navigation Link

Add to your sidebar/nav:
```tsx
<NavLink to="/pricing-matrix">
  <DollarSign size={18} />
  Pricing Matrix
</NavLink>
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/consigner-prices/matrix` | Get the full pricing matrix |
| `POST` | `/api/consigner-prices` | Create a new price entry |
| `PATCH` | `/api/consigner-prices/{id}` | Update a price entry |
| `DELETE` | `/api/consigner-prices/{id}` | Deactivate a price entry |
| `POST` | `/api/consigner-prices/bulk` | Bulk create/update prices |
| `GET` | `/api/consigner-prices/lookup/player/{id}` | Get best price for a player |
| `GET` | `/api/consigner-prices/consigner/{id}/summary` | Get consigner's pricing stats |
| `GET` | `/api/consigner-prices/consigner/{id}/prices` | Get all prices for a consigner |

### Matrix Query Parameters

```
GET /api/consigner-prices/matrix?player_search=caminero&only_with_prices=true&limit=50&offset=0
```

- `player_search` - Filter players by name
- `consigner_ids` - Comma-separated list of consigner UUIDs to include
- `only_with_prices` - Only show players with at least one price
- `limit` / `offset` - Pagination

---

## Usage

### Pricing Matrix Page

1. Navigate to `/pricing-matrix`
2. See all players as rows, consigners as columns
3. **Click any cell** to add/edit a price
4. Green highlighting shows the best (lowest) price for each player
5. Summary row shows stats for each consigner

### Using in Consignment Creation

Import the `PriceSuggestion` component:

```tsx
import { PriceSuggestion } from '../components/PriceSuggestion';

// In your consignment item row:
<PriceSuggestion
  playerId={item.player_id}
  consignerId={selectedConsignerId}
  onPriceSelect={(price) => setFeeForItem(item.id, price)}
  showAllOptions={true}
/>
```

This will:
- Show the price for the selected consigner
- Indicate if another consigner has a better price
- Allow clicking to auto-fill the fee field

### Inline Price Display

For tables/lists showing inventory:

```tsx
import { InlinePrice } from '../components/PriceSuggestion';

// In a table cell:
<InlinePrice playerId={card.player_id} consignerId={consigner.id} />
```

---

## Data Model

```
┌─────────────────────────────────────────────────────────────┐
│                  consigner_player_prices                     │
├─────────────────────────────────────────────────────────────┤
│ id              UUID PRIMARY KEY                             │
│ consigner_id    UUID FK → consigners(id)                    │
│ player_id       UUID FK → players(id)                       │
│ price_per_card  DECIMAL(10,2)                               │
│ notes           TEXT (optional)                              │
│ effective_date  DATE (optional)                              │
│ is_active       BOOLEAN (soft delete)                        │
│ created_at      TIMESTAMP                                    │
│ updated_at      TIMESTAMP                                    │
└─────────────────────────────────────────────────────────────┘
```

---

## Example Workflow

1. **Mike** charges $40 for Junior Caminero autographs
2. **Dave** charges $35 for the same player
3. **Joe** hasn't quoted Caminero yet

In the matrix:
```
| Player           | Mike  | Dave  | Joe | Best  |
|------------------|-------|-------|-----|-------|
| Junior Caminero  | $40   | $35*  | —   | $35   |
| Druw Jones       | $50*  | $55   | $60 | $50   |
```

When creating a consignment with Dave:
- System auto-suggests $35 for Caminero cards
- Shows "Best available price ✓" indicator

---

## Testing Checklist

- [ ] Migration runs without errors
- [ ] `/api/consigner-prices/matrix` returns data
- [ ] Clicking cells allows inline editing
- [ ] Creating a price shows in the matrix
- [ ] Best price highlighting works
- [ ] Player search filters correctly
- [ ] "Only with prices" toggle works
- [ ] Export CSV downloads valid file
- [ ] Pagination works for large player lists
