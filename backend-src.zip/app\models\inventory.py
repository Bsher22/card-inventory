"""
Inventory Model
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, TYPE_CHECKING
import uuid

from sqlalchemy import String, Integer, Text, Boolean, DateTime, Numeric, ForeignKey, UniqueConstraint, CheckConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from .base import Base

if TYPE_CHECKING:
    from .checklists import Checklist
    from .card_types import CardBaseType, Parallel


class Inventory(Base):
    """Inventory tracking - what cards you own"""
    __tablename__ = "inventory"
    __table_args__ = (
        UniqueConstraint(
            'checklist_id', 'is_signed', 'is_slabbed',
            'grade_company', 'grade_value', 'raw_condition',
            name='uq_inventory_card_status'
        ),
        CheckConstraint('quantity >= 0', name='ck_inventory_quantity_positive'),
    )

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    checklist_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("checklists.id", ondelete="CASCADE"), nullable=False)
    
    # Card type references (from card_types module)
    base_type_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("card_base_types.id", ondelete="SET NULL")
    )
    parallel_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("parallels.id", ondelete="SET NULL")
    )
    
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    serial_number: Mapped[Optional[int]] = mapped_column(Integer)  # e.g., 142 of /250

    # Card status
    is_signed: Mapped[bool] = mapped_column(Boolean, default=False)
    is_slabbed: Mapped[bool] = mapped_column(Boolean, default=False)

    # Grading info (for slabbed cards)
    grade_company: Mapped[Optional[str]] = mapped_column(String(20))  # PSA, BGS, SGC
    grade_value: Mapped[Optional[Decimal]] = mapped_column(Numeric(4, 1))  # 10, 9.5, 9, etc.
    auto_grade: Mapped[Optional[Decimal]] = mapped_column(Numeric(4, 1))
    cert_number: Mapped[Optional[str]] = mapped_column(String(50))

    # Raw card condition (for non-slabbed)
    raw_condition: Mapped[str] = mapped_column(String(20), default="NM")

    # Storage & tracking
    storage_location: Mapped[Optional[str]] = mapped_column(String(100))
    notes: Mapped[Optional[str]] = mapped_column(Text)

    # Cost tracking - accumulates purchase + fees
    total_cost: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=0)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    checklist: Mapped["Checklist"] = relationship(back_populates="inventory_items")
    base_type: Mapped[Optional["CardBaseType"]] = relationship(
        back_populates="inventory_items",
        foreign_keys=[base_type_id]
    )
    parallel: Mapped[Optional["Parallel"]] = relationship(
        back_populates="inventory_items",
        foreign_keys=[parallel_id]
    )
